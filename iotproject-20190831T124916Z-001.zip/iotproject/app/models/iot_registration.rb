class IotRegistration < ApplicationRecord
end
