class SignUp < ApplicationRecord
    validates :name, :age, :address, :email, :password, presence: true
    validates :name, uniqueness: true
    validates :age, numericality: { greater_than_or_equal_to: 18, less_than_or_equal_to: 120 }, acceptance: { message: 'enter valid age' }
    validates_length_of :password, :minimum => 4, :allow_blank => true
end
