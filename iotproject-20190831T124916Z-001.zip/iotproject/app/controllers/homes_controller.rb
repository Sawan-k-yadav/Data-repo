class HomesController < ApplicationController
  layout 'pre_layout' 

  def index
    if session[:user_id].present?
      @user = SignUp.find(session[:user_id])
      render 'users/mainindex', layout: "post_layout"
    else
      render :action => :index
    end
  end

  def contact_us
    if session[:user_id].present?
      @user = SignUp.find(session[:user_id])
      render 'users/mainindex', layout: "post_layout"
    else
      render :action => :contact_us
    end
   end

  def about_us
    if session[:user_id].present?
      @user = SignUp.find(session[:user_id])
      render 'users/mainindex', layout: "post_layout"
    else
      render :action => :about_us
    end
   end

  def sign_up
    if session[:user_id].present?
      @user = SignUp.find(session[:user_id])
      render 'users/mainindex', layout: "post_layout"
    else
      render :action => :sign_up
    end
  end

  def login
    if session[:user_id].present?
      render 'users/mainindex', layout: "post_layout"
    else
      render :action => :login
    end
  end

  
  def show
    @error1 = []
    @error1 << "name is required," if params[:name].blank?
    @error1 << "age is required," if params[:age].blank?
    @error1 << "address is required," if params[:address].blank?
    @error1 << "email is required," if params[:email].blank?
    @error1 << "password is required" if params[:password].blank?
    @user  = SignUp.create(name: params[:name], age: params[:age], address: params[:address], email: params[:email],password: params[:password])
      
    if @error1.present?
      render :action => :sign_up
    else
      render :action => :show
    end 
  end
end
