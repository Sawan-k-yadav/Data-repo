class UsersController < ApplicationController
  layout 'post_layout' 

  def mainindex
    user = SignUp.where("email = ? or name = ? and password = ?", params[:email], params[:name], params[:password]).first
    
    if user.present?
        session[:user_id] = user.id
    end

    if session[:user_id].present?
      @user = SignUp.find(session[:user_id])
      render :action => :mainindex
    else
      redirect_to login_path
      flash[:alert] = "Email/Password does not match."
    end
  end

  def log_out
    reset_session
    redirect_to root_path
  end
end
