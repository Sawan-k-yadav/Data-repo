Rails.application.routes.draw do
  root 'homes#index'

  get 'users/index'
  get 'index',      to: 'homes#index'
  get 'contact_us', to: 'homes#contact_us'
  get 'about_us',   to: 'homes#about_us'
  get 'sign_up',    to: 'homes#sign_up'
  get 'show',       to: 'homes#show'
  post 'show',      to: 'homes#show'
  get 'login',      to: 'homes#login'
  get 'users/mainindex',  to: 'users#mainindex'
  post 'users/mainindex',  to: 'users#mainindex'
  get 'users/log_out',  to: 'users#log_out'

  resources :homes
  resources :users
end
