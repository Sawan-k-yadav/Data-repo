require 'test_helper'

class IotRegistrationTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
