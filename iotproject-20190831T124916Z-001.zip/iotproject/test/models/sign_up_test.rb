require 'test_helper'

class SignUpTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
